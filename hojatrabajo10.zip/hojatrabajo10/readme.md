# Logistics Graph with Floyd–Warshall Hoja trabajo 10

## Adrian Arimany - 211063
## Rodrigo Sebastián Ajmac Aroche - 22279

## Requirements

- Python 3.8+ (Ubuntu: `sudo apt install python3 python3-venv`)
- (Optional) Create a virtualenv:

## Assiment architecture:


- Readme.md
- logisica.txt (This is the file to run the test)
- graph.py (this is the Floyd Algorithm)
- main.py (To run the prgram)
- test (To test the algoritm)
    - test_graph.py (The units tests for the algorithm)


## TO run the unit tests please use the following command:

```
python3 -m unittest discover -s test -p 'test_*.py'
```